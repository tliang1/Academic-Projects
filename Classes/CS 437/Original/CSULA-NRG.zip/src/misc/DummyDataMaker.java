package misc;

import java.util.*;

import types.*;

public class DummyDataMaker {

//	public static void main(String[] args) {
//		int entries = 20;
//		
//		Device device;
//		WeatherData weather;
//		GridData grid;
//		for(int i = 0; i < entries; i++){
//			device = new Device();
//			weather = new WeatherData(i / 24 + 1, i % 24);
//			grid = new GridData(i / 24 + 1, i % 24);
//			System.out.println(grid.toSqlEntry());
//			System.out.println(device.toSqlEntry());
//		}
//	}
	
	int entries = 20;
	
	List<Device> devices = new ArrayList<Device>();
	List<WeatherData> weatherData = new ArrayList<WeatherData>();
	List<GridData> gridData = new ArrayList<GridData>();
	Device device;
	WeatherData weather;
	GridData grid;
	
	public DummyDataMaker() {
		for(int i = 0; i < entries; i++){
			device = new Device();
			devices.add(device);
//			weather = new WeatherData(i / 24 + 1, i % 24);
//			weatherData.add(weather);
//			grid = new GridData(i / 24 + 1, i % 24);
//			gridData.add(grid);
		}
	}

	public List<Device> getDevices() {
		return devices;
	}

	public List<WeatherData> getWeatherData() {
		return weatherData;
	}

	public List<GridData> getGridData() {
		return gridData;
	}
}

//package misc;
//
//import types.Device;
//import types.GridData;
//import types.WeatherData;
//
//
//public class DummyDataMaker {
//	
//	public static void main(String[] args){
//		
//		int entries = 20;
//		
//		Device device;
//		WeatherData weather;
//		GridData grid;
//		
//		
//		for(int i = 0; i < entries; i++){
//			
//			//device = new Device();
//			//weather = new WeatherData(i / 24 + 1, i % 24);
//			grid = new GridData(i / 24 + 1, i % 24);
//			System.out.println(grid.toSqlEntry());
//			
//		}
//		
//	}
//
//}
