package functions.rf;

import java.io.*;
import java.sql.*;
import java.util.*;

import javax.swing.JFrame;

import functions.dmf.DMF;

import types.*;

import misc.DummyDataMaker;

public class NRGResponse {
	
	static int currentDeficit;
	static List<Device> sortedDevices;
	static DevicesTable dt;
	static ResponseFunction rf;

	public static void mainDemo() {

		try {
			
			DMF dmf = new DMF();

			
		    // Insert data to the tables
		    DummyDataMaker ddm = new DummyDataMaker();

		    for (int i = 0; i < ddm.getDevices().size(); i++) {
		    	dmf.insertDevice(ddm.getDevices().get(i));
		    }
		    
		    
		    // Generate a random deficit
		    currentDeficit = randomCurrentDeficit(ddm.getDevices());
		    
		    rf = new ResponseFunction(dmf.getAllDevices(), currentDeficit, dmf);
		        
		    // Rank the devices in order of importance (0: Most important, 9: Least important)
		    sortedDevices = rf.importanceSort(dmf.getAllDevices());
		    
		    dt = new DevicesTable(sortedDevices, sortedDevices.size(), rf.totalPriority(sortedDevices), totalDeviceUsage(dmf.getAllDevices()), 0);
		    System.out.println("Total Device Usage: " + totalDeviceUsage(dmf.getAllDevices()));
		    
		    
		    dt.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		    while(!dt.isClicked()) {
		        	
		    }
		        
		    System.out.println("Current Deficit: " + currentDeficit);
		    
		    List<Device> modifiedDevices = rf.powerConsumption(sortedDevices);
		    System.out.println("Total Device Usage After: " + totalDeviceUsage(modifiedDevices));
		    
		    dt = new DevicesTable(modifiedDevices, rf.wattsToPercent(modifiedDevices), sortedDevices.size(), currentDeficit, rf.totalPriority(sortedDevices));
		        
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public static void buttonMethod(){
	    System.out.println("Current Deficit: " + currentDeficit);
	    
	    
	    List<Device> modifiedDevices = rf.powerConsumption(sortedDevices);
	    System.out.println("Total Device Usage After: " + totalDeviceUsage(modifiedDevices));
	    dt.dispose();
	    dt = new DevicesTable(modifiedDevices, rf.wattsToPercent(modifiedDevices), sortedDevices.size(), currentDeficit, rf.totalPriority(sortedDevices));
	    dt.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	static int totalDeviceUsage(List<Device> devices) {
		
		int totalDeviceUsage = 0;
		
		for (int i = 0; i < devices.size(); i++) {
			totalDeviceUsage += devices.get(i).getDeviceUsage();
		}
		
		return totalDeviceUsage;
	}
	
	static int randomCurrentDeficit(List<Device> devices) {
		
		Random random = new Random();
		int currentDeficit = random.nextInt(totalDeviceUsage(devices) + 1);
		
		return currentDeficit;
	}
}

