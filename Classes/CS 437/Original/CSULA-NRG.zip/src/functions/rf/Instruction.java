package functions.rf;

import java.awt.List;

import types.Device;


public class Instruction {

	public void create(List d){
		/*send instruction to response function*/
		
	}
	public void destory(List d){
		/*destory current instructions*/
	}
}
