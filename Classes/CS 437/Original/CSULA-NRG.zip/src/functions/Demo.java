package functions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import functions.cf.CF;
import functions.dmf.DMF;
import functions.pf.PF;
import functions.rf.NRGResponse;

public class Demo {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws IOException, SQLException {
		char input = 'a';
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);	
		
		while(input != 'q'){
			System.out.println("*****************************************");
			System.out.println("*****        NRG Demo System        *****");
			System.out.println("*****************************************\n");
			System.out.println("1) Data Management Function Demo");
			System.out.println("2) Predictive Function Demo");
			System.out.println("3) Response Function Demo");
			System.out.println("4) Control Function Demo\n");
			System.out.println("q) Exit");
			
			input = sc.next().charAt(0);
			
			System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			
			switch(input){
			case '1': DMF.mainDemo();
				break;
			case '2': PF.mainDemo();
				break;
			case '3': NRGResponse.mainDemo();
				break;
			case '4': CF.mainDemo();
				break;
			case 'q': System.out.println("Exiting...");
				break;
			default: System.out.println("Invalid input");
				sc.nextLine();
				break;
			}
			
			
		}
	}

}
